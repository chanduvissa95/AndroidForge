# NIFTY 50 Trading Assistant — Android starter

This is a starter implementation, not a finished or audited trading system. It separates simulated paper trading from real broker orders. Live execution is disabled by default.

## Verified Groww API position (checked 4 Nov 2026)

Groww publishes a Trading API for NSE/BSE cash and F&O, including live market data, historical data, option chain, orders, positions, and order status. Its docs state an active Trading API subscription is required. The published pricing page currently advertises ₹499 + taxes/month for live data and order APIs, with other pricing tiers/features shown on the page; verify current plan details in your Groww account before paying.

- Overview: https://groww.in/trade-api
- API docs: https://groww.in/trade-api/docs
- cURL authentication and API requirements: https://groww.in/trade-api/docs/curl
- Live data / option chain: https://groww.in/trade-api/docs/curl/live-data
- Order placement: https://groww.in/trade-api/docs/curl/orders

The API docs describe a generated access token that expires daily at 6:00 AM, or API-key/secret flow requiring daily approval on Groww Cloud API Keys page. Do not put the token, key, or secret in the Android app. Keep them on the backend. Confirm current terms, subscription, account eligibility, and any exchange/broker requirements with Groww before enabling real orders.

## Architecture

- Android: Kotlin + Jetpack Compose. UI starter exposes Market, Paper, and Live review areas.
- Backend: FastAPI. Owns credentials, broker integration, order validation, audit log, and risk checks.
- Market data: Groww APIs for live quotes, historical candles, and option chain when authenticated; FII/DII data needs a separately verified source. Do not infer live data from mock values.
- Paper trading: separate in-memory demo ledger in this starter. It uses an explicitly supplied simulated fill price; replace with persistent database and market-feed-driven simulation before real use.
- Live trading: backend adapter uses Groww order endpoint only when `LIVE_TRADING_ENABLED=true` and a valid server-side `GROWW_ACCESS_TOKEN` exists. Each order requires a preview, then a second confirmation request. Never treat a preview as an order.
- Storage for production: PostgreSQL for ledger/audit and encrypted secrets manager for credentials. Use Android Keystore only for app-side session material, never broker secrets.

## Run the backend locally

Requires Python 3.11+.

```bash
cd backend
python -m venv .venv
# Windows PowerShell: .venv\\Scripts\\Activate.ps1
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

Open http://127.0.0.1:8000/docs for the local API. Live trading stays disabled unless explicitly configured. Do not expose this development server to the public internet.

### Backend environment variables

Copy `.env.example` to `.env` only for local development and load it using your preferred environment loader; never commit `.env`.

- `LIVE_TRADING_ENABLED=false` by default.
- `GROWW_ACCESS_TOKEN` must be a valid current Groww token. It expires; use Groww's official authentication flow. Do not paste credentials into chat or source control.
- `LIVE_MAX_ORDER_QTY` sets a conservative server-side quantity cap.

Before enabling live mode, implement authenticated user sessions, CSRF/replay protection, persistent idempotency keys, broker order reconciliation, audit logs, and independent risk limits. This starter is not production-hardened.

## Android Studio / APK build

1. Install Android Studio and a current Android SDK.
2. Open the `android` folder as a project. Allow Gradle sync.
3. For emulator testing, backend URL defaults to `http://10.0.2.2:8000/` (emulator-to-host mapping). For a physical phone, use your computer's LAN IP and keep both devices on a trusted network. Do not use cleartext HTTP on production builds.
4. Start backend first, then Run the Android app.
5. Build a debug APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)**. Android Studio shows the output path.
6. For release, configure signing in Android Studio, use HTTPS, authenticate the app, and test on a dedicated broker test workflow / paper mode before enabling real orders.

The current Android folder is a source starter; a successful APK build requires a local Android SDK and Gradle dependency resolution. It has not been built or device-tested in this environment.

## Trading safeguards and limitations

- Paper and live endpoints are separate. Paper orders cannot call the broker adapter.
- Live orders require preview + manual confirmation phrase and backend enable flag.
- A limit order is preferred for review. Market orders can slip; stop-loss orders can fail or fill worse than expected in fast markets.
- Option premium risk is not equal to index-point risk. Calculate lot size and maximum loss using the actual contract, premium, lot size, and execution costs.
- The starter does not generate trading signals, fetch FII/DII data, or backtest strategies yet. Add those as separate modules with sourced/timestamped data and walk-forward tests.
- Never treat model output as a guaranteed signal. Review every order and confirm symbol, expiry, strike, option type, side, quantity, price, and product before submission.
