from __future__ import annotations

import os
import secrets
import time
from typing import Literal

import httpx
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

app = FastAPI(title="NIFTY Trading Assistant API", version="0.1.0")

LIVE_ENABLED = os.getenv("LIVE_TRADING_ENABLED", "false").lower() == "true"
GROWW_TOKEN = os.getenv("GROWW_ACCESS_TOKEN", "").strip()
LIVE_MAX_ORDER_QTY = max(1, int(os.getenv("LIVE_MAX_ORDER_QTY", "1")))
PAPER_STARTING_CASH = 100_000.0

# Demo-only memory store. Use a transactional persistent database in production.
paper_cash = PAPER_STARTING_CASH
paper_trades: list[dict] = []
pending_live: dict[str, dict] = {}

class PaperOrder(BaseModel):
    instrument_type: Literal["OPTION", "FUTURE_SIM", "INDEX_SIM"]
    symbol: str = Field(min_length=1, max_length=80)
    side: Literal["BUY", "SELL"]
    quantity: int = Field(gt=0, le=100000)
    simulated_fill_price: float = Field(gt=0)
    note: str = Field(default="", max_length=500)

class LivePreview(BaseModel):
    trading_symbol: str = Field(min_length=1, max_length=80)
    quantity: int = Field(gt=0, le=100000)
    exchange: Literal["NSE", "BSE"] = "NSE"
    segment: Literal["FNO", "CASH"] = "FNO"
    product: str = Field(min_length=1, max_length=20)
    order_type: Literal["LIMIT", "MARKET", "SL", "SL-M"]
    transaction_type: Literal["BUY", "SELL"]
    validity: Literal["DAY", "IOC"] = "DAY"
    price: float | None = Field(default=None, gt=0)
    trigger_price: float | None = Field(default=None, gt=0)

class LiveConfirm(BaseModel):
    preview_id: str
    confirmation_text: str

@app.get("/api/status")
def status():
    return {
        "status": "ok",
        "paper_trading": True,
        "live_trading_enabled": LIVE_ENABLED and bool(GROWW_TOKEN),
        "live_broker": "Groww" if LIVE_ENABLED and GROWW_TOKEN else None,
        "warning": "No live market data is shown by this starter unless authenticated data endpoints are implemented.",
    }

@app.get("/api/paper/portfolio")
def paper_portfolio():
    return {"environment": "PAPER", "starting_cash": PAPER_STARTING_CASH,
            "cash_balance": round(paper_cash, 2), "trades": paper_trades[-100:]}

@app.post("/api/paper/order")
def create_paper_order(order: PaperOrder):
    global paper_cash
    gross = order.quantity * order.simulated_fill_price
    # Simple cash ledger for demo; not a full options/futures margin model.
    if order.side == "BUY" and gross > paper_cash:
        raise HTTPException(400, "Insufficient paper cash for this simple simulated order.")
    if order.side == "BUY":
        paper_cash -= gross
    else:
        paper_cash += gross
    trade = {"id": secrets.token_hex(8), "environment": "PAPER", **order.model_dump(),
             "gross_value": round(gross, 2), "created_at": int(time.time()),
             "disclaimer": "Fill price was supplied by the user; this is not a market fill."}
    paper_trades.append(trade)
    return trade

@app.post("/api/live/preview")
def preview_live_order(order: LivePreview):
    if not LIVE_ENABLED or not GROWW_TOKEN:
        raise HTTPException(403, "Live trading is disabled. Configure a valid server-side Groww token and explicitly enable live trading only after security review.")
    if order.quantity > LIVE_MAX_ORDER_QTY:
        raise HTTPException(400, f"Quantity exceeds configured live cap ({LIVE_MAX_ORDER_QTY}).")
    if order.order_type == "LIMIT" and order.price is None:
        raise HTTPException(400, "Limit orders require a price.")
    if order.order_type in ("SL", "SL-M") and order.trigger_price is None:
        raise HTTPException(400, "Stop orders require a trigger price.")
    preview_id = secrets.token_urlsafe(18)
    payload = order.model_dump()
    payload["preview_id"] = preview_id
    payload["environment"] = "LIVE - NOT SUBMITTED"
    payload["confirmation_text_required"] = "SUBMIT LIVE ORDER"
    payload["warning"] = "Review symbol, expiry, strike, side, quantity, order type, price, and risk. This preview has not placed an order."
    pending_live[preview_id] = {"order": order.model_dump(), "created": time.time()}
    return payload

@app.post("/api/live/confirm")
async def confirm_live_order(confirm: LiveConfirm):
    if not LIVE_ENABLED or not GROWW_TOKEN:
        raise HTTPException(403, "Live trading is disabled.")
    if confirm.confirmation_text != "SUBMIT LIVE ORDER":
        raise HTTPException(400, "Confirmation phrase does not match.")
    item = pending_live.pop(confirm.preview_id, None)
    if not item:
        raise HTTPException(404, "Preview not found, already used, or expired. Generate a new preview.")
    if time.time() - item["created"] > 120:
        raise HTTPException(410, "Preview expired. Review and create a new preview.")

    order = item["order"]
    reference = "Nifty" + secrets.token_hex(7)  # 12 alphanumeric chars
    payload = {
        "trading_symbol": order["trading_symbol"], "quantity": order["quantity"],
        "validity": order["validity"], "exchange": order["exchange"],
        "segment": order["segment"], "product": order["product"],
        "order_type": order["order_type"], "transaction_type": order["transaction_type"],
        "order_reference_id": reference,
    }
    if order.get("price") is not None:
        payload["price"] = order["price"]
    if order.get("trigger_price") is not None:
        payload["trigger_price"] = order["trigger_price"]
    headers = {"Authorization": f"Bearer {GROWW_TOKEN}", "Accept": "application/json",
               "Content-Type": "application/json", "X-API-VERSION": "1.0"}
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.post("https://api.groww.in/v1/order/create", headers=headers, json=payload)
        response.raise_for_status()
        body = response.json()
    except httpx.HTTPError as exc:
        # Do not blindly retry: network failures can leave order status uncertain.
        raise HTTPException(502, f"Broker response unavailable; verify order book in Groww before retrying. Details: {type(exc).__name__}")
    if body.get("status") != "SUCCESS":
        raise HTTPException(502, {"message": "Groww did not confirm success", "broker_response": body})
    return {"environment": "LIVE", "broker": "Groww", "submitted": True, "response": body,
            "note": "Check Groww order book and fill status. Submission is not the same as execution."}
