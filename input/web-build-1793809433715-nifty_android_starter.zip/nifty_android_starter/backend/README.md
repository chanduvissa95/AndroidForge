# Backend implementation notes

This starter provides a demo paper ledger and a gated Groww live-order preview/confirmation path. It does not yet implement market-data ingestion, signal generation, a persistent ledger, user authentication, or production-grade security.

Do not enable public access or live orders until you add authentication, authorization, TLS, secret management, database transactions, audit logs, idempotency/reconciliation, rate limiting, and independent risk review.
