package com.example.niftyassistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

private enum class AppMode { ANALYSIS, PAPER, LIVE }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { TradingAssistantApp() } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TradingAssistantApp() {
    var mode by remember { mutableStateOf(AppMode.ANALYSIS) }
    var liveDisclaimerAccepted by remember { mutableStateOf(false) }
    var paperBalance by remember { mutableStateOf(100000.0) }
    var symbol by remember { mutableStateOf("NIFTY") }
    var quantity by remember { mutableStateOf("1") }
    var fillPrice by remember { mutableStateOf("100") }
    var message by remember { mutableStateOf("Paper trading uses virtual money only.") }

    Scaffold(topBar = { TopAppBar(title = { Text("NIFTY Trading Assistant") }) }) { padding ->
        Column(Modifier.padding(padding).padding(16.dp).fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Market analysis • Paper trading • Groww live review", style = MaterialTheme.typography.bodyMedium)
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                listOf(AppMode.ANALYSIS, AppMode.PAPER, AppMode.LIVE).forEachIndexed { index, item ->
                    SegmentedButton(selected = mode == item, onClick = { mode = item }, shape = SegmentedButtonDefaults.itemShape(index, 3)) {
                        Text(when (item) { AppMode.ANALYSIS -> "Analysis"; AppMode.PAPER -> "Paper"; AppMode.LIVE -> "Live" })
                    }
                }
            }
            when (mode) {
                AppMode.ANALYSIS -> {
                    Text("Market Analysis", style = MaterialTheme.typography.headlineSmall)
                    Text("Connect authenticated market data to display live NIFTY quotes, candles, indicators, support/resistance and option-chain OI.")
                    Text("Data status: NOT CONNECTED", color = MaterialTheme.colorScheme.error)
                    Text("No live price or trading signal is fabricated in this starter.")
                }
                AppMode.PAPER -> {
                    Text("Paper Trading", style = MaterialTheme.typography.headlineSmall)
                    Text("Virtual balance: ₹${"%,.2f".format(paperBalance)}")
                    OutlinedTextField(value = symbol, onValueChange = { symbol = it }, label = { Text("Symbol / contract") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = quantity, onValueChange = { quantity = it.filter(Char::isDigit) }, label = { Text("Quantity") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = fillPrice, onValueChange = { fillPrice = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("Simulated fill price (₹)") }, modifier = Modifier.fillMaxWidth())
                    Button(onClick = {
                        val q = quantity.toIntOrNull() ?: 0
                        val p = fillPrice.toDoubleOrNull() ?: 0.0
                        if (q > 0 && p > 0 && q * p <= paperBalance) {
                            paperBalance -= q * p
                            message = "SIMULATED BUY recorded for $symbol: $q × ₹$p. No market fill occurred."
                        } else message = "Check quantity, simulated price, and virtual balance."
                    }, modifier = Modifier.fillMaxWidth()) { Text("Simulate BUY") }
                    Text(message)
                    Text("This simple UI demo is not yet connected to the backend ledger or real-time prices.", style = MaterialTheme.typography.bodySmall)
                }
                AppMode.LIVE -> {
                    Text("Groww Live Trading", style = MaterialTheme.typography.headlineSmall)
                    Text("Live orders are disabled until the backend is secured and a valid Groww API subscription/token is configured.")
                    Text("Workflow: prepare order → review symbol/expiry/strike/side/quantity/price → approve → submit → verify in Groww order book.")
                    Row { Checkbox(checked = liveDisclaimerAccepted, onCheckedChange = { liveDisclaimerAccepted = it }); Text("I understand real orders can lose money and this starter does not yet submit from this screen.") }
                    Button(onClick = { message = if (liveDisclaimerAccepted) "Live mode remains unavailable in this Android demo. Use the secured backend preview/confirmation workflow after implementation and testing." else "Please acknowledge the live-trading risk first." }, modifier = Modifier.fillMaxWidth()) { Text("Review live trading requirements") }
                    Text(message)
                }
            }
            HorizontalDivider()
            Text("Risk controls", style = MaterialTheme.typography.titleMedium)
            Text("Keep paper/live ledgers separate. Require manual confirmation for every live order. Apply quantity caps, daily loss limits, stale-price checks, idempotency, and broker order reconciliation before production.")
        }
    }
}
